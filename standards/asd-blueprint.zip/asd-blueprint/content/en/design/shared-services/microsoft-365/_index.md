---
title: "Microsoft 365"
weight: 5
description: "This section describes the design decisions associated with Microsoft 365 for system(s) built using ASD's Blueprint for Secure Cloud."
---

