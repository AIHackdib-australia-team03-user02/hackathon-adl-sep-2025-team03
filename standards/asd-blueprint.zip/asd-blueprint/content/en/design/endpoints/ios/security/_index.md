---
title: "iOS Security"
weight: 20
description: "This section describes the design decisions associated with iOS endpoints configured according to guidance in ASD's Blueprint for Secure Cloud."
---