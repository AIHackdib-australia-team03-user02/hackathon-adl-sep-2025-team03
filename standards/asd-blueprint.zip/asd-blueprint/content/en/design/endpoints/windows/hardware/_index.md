---
title: "Windows Hardware"
weight: 10
description: "This section describes the design decisions associated with Windows 10 and 11 endpoints configured according to guidance in ASD's Blueprint for Secure Cloud."
---
