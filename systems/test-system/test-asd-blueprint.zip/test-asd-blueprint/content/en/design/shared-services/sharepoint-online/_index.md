---
title: "SharePoint"
weight: 25
description: "This section describes the design decisions associated with SharePoint for system(s) built using ASD's Blueprint for Secure Cloud."
---