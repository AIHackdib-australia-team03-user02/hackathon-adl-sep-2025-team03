---
title: "Power Platform"
weight: 40
description: "This section describes the design decisions associated with Power Platform for system(s) built using ASD's Blueprint for Secure Cloud."
---

Power Platform combines the power of PowerApps, Power BI, and Power Automate (formerly Microsoft Flow) into one business application platform, enabling quick and easy app building and data insights.
