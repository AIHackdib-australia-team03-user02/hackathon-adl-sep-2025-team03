---
title: "Endpoints"
weight: 30
description: "This section describes the design decisions associated with endpoints configured according to guidance in ASD's Blueprint for Secure Cloud."
---