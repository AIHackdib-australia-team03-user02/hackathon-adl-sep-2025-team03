---
title: "Applications"
weight: 10
description: "This section describes the design decisions associated with common applications on endpoints configured according to guidance in ASD's Blueprint for Secure Cloud."
---