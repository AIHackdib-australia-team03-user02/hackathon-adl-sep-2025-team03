---
title: "iOS Configuration"
weight: 10
description: "This section describes the design decisions associated with iOS endpoints configured according to guidance in ASD's Blueprint for Secure Cloud."
---
