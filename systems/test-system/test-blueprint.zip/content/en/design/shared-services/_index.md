---
title: "Shared Services"
weight: 30
description: "This section describes the design decisions associated with shared services components such as Exchange Online, SharePoint Online, OneDrive for Business, and Microsoft Teams for system(s) built using ASD's Blueprint for Secure Cloud."
---