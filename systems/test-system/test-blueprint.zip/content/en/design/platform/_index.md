---
title: "Platform"
weight: 20
description: "This section describes the design decisions associated with platform components such as identity management, service connectivity, endpoint management, and platform security for system(s) built using ASD's Blueprint for Secure Cloud."
---